#ifndef GOERTZEL_H_
#define GOERTZEL_H_

#include <Arduino.h>
#include "MorsePreferences.h"

namespace Goertzel 
{
  void setup();
  boolean checkInput();
}


#endif /* GOERTZEL_H_ */
