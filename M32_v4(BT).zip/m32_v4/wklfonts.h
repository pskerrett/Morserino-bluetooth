#ifndef WKLFONTS_H
#define WKLFONTS_H

#include <Arduino.h>

// Created by http://oleddisplay.squix.ch/ Consider a donation
// In case of problems make sure that you are using the font file with the correct version!
extern uint8_t DialogInput_plain_12[] PROGMEM;

// Created by http://oleddisplay.squix.ch/ Consider a donation
// In case of problems make sure that you are using the font file with the correct version!
extern uint8_t DialogInput_plain_15[] PROGMEM;

// Created by http://oleddisplay.squix.ch/ Consider a donation
// In case of problems make sure that you are using the font file with the correct version!
extern uint8_t DialogInput_bold_12[] PROGMEM;

// Created by http://oleddisplay.squix.ch/ Consider a donation
// In case of problems make sure that you are using the font file with the correct version!
extern uint8_t DialogInput_bold_15[] PROGMEM;

#endif
